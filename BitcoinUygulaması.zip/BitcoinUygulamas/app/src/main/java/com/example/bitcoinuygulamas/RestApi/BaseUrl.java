package com.example.bitcoinuygulamas.RestApi;

public class BaseUrl {
    public static  final String bilgi_URL = "http://api.coinranking.com";
}
